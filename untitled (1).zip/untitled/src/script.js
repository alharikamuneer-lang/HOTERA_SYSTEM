// 1. دالة رفع البيانات السحابية (تضمين رمز السوبر أدمن)
async function syncDataWithCloudNow() {
  if(!cloudApiUrl) {
    alert("⚠️ الرجاء إدخال رابط الـ API السحابي أولاً في خانة الإعدادات السحابية!");
    return;
  }
  try {
    const statusText = document.getElementById('cloudSyncStatusText');
    if(statusText) statusText.innerText = "الحالة: جاري المزامنة مع السحابة... ⏳";
    
    const payload = {
      masterSuperKey: masterSuperKey,
      developerName: developerName,
      developerPhone: developerPhone,
      aboutPageTitleText: aboutPageTitleText,
      aboutPageDescText: aboutPageDescText,
      hotels: hotelsList,
      rooms: allRooms,
      invoices: allInvoices,
      transactions: allTransactions,
      timestamp: new Date().toISOString()
    };
    
    const response = await fetch(cloudApiUrl, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        ...(cloudApiKey ? { 'X-Master-Key': cloudApiKey, 'Authorization': `Bearer ${cloudApiKey}` } : {})
      },
      body: JSON.stringify(payload)
    });
    
    if(response.ok) {
      if(statusText) statusText.innerText = "الحالة: تمت المزامنة السحابية بنجاح ✅";
    } else {
      throw new Error("فشل الاتصال بالخادم السحابي");
    }
  } catch (err) {
    console.error(err);
    const statusText = document.getElementById('cloudSyncStatusText');
    if(statusText) statusText.innerText = "الحالة: خطأ في الاتصال ❌";
  }
}
// 2. دالة جلب أحدث البيانات والأكواد من السحابة
async function fetchDataFromCloud(isSilent = true) {
  if(!cloudApiUrl) return false;
  try {
    const response = await fetch(cloudApiUrl, {
      method: 'GET',
      headers: {
        ...(cloudApiKey ? { 'X-Master-Key': cloudApiKey, 'Authorization': `Bearer ${cloudApiKey}` } : {})
      }
    });
    
    if(response.ok) {
      const result = await response.json();
      const payload = result.record ? result.record : result;
      
      // تحديث كلمة مرور السوبر أدمن إذا وجدت في السحابة
      if(payload.masterSuperKey) {
        masterSuperKey = payload.masterSuperKey;
        localStorage.setItem('hotera_master_key', masterSuperKey);
      }
      if(payload.developerName) { developerName = payload.developerName; localStorage.setItem('hotera_dev_name', developerName); }
      if(payload.developerPhone) { developerPhone = payload.developerPhone; localStorage.setItem('hotera_dev_phone', developerPhone); }
      if(payload.hotels) { hotelsList = payload.hotels; localStorage.setItem('hotera_all_hotels', JSON.stringify(hotelsList)); }
      if(payload.rooms) { allRooms = payload.rooms; localStorage.setItem('hotera_all_rooms', JSON.stringify(allRooms)); }
      if(payload.invoices) { allInvoices = payload.invoices; localStorage.setItem('hotera_all_invoices', JSON.stringify(allInvoices)); }
      if(payload.transactions) { allTransactions = payload.transactions; localStorage.setItem('hotera_all_transactions', JSON.stringify(allTransactions)); }
      
      updateGlobalDisplays();
      if(!isSilent) alert("✅ تم جلب أحدث الأكواد والبيانات من السحابة بنجاح!");
      return true;
    }
  } catch(err) {
    console.error("خطأ أثناء جلب البيانات السحابية:", err);
  }
  return false;
}
// 3. تحديث إعدادات السوبر أدمن ورفعها فوراً للسحابة
function updateSuperAdminSettings() {
  const devNameInput = document.getElementById('editSuperDevName').value.trim();
  const devPhoneInput = document.getElementById('editSuperDevPhone').value.trim();
  const newKey = document.getElementById('newSuperAdminKeyInput').value.trim();
  
  if(devNameInput) developerName = devNameInput;
  if(devPhoneInput) developerPhone = devPhoneInput;
  if(newKey) masterSuperKey = newKey;
  
  saveData();
  updateGlobalDisplays();
  document.getElementById('newSuperAdminKeyInput').value = '';
  
  if(cloudApiUrl) {
    syncDataWithCloudNow();
    alert("✅ تم حفظ كلمة المرور الجديدة وتحديثها على السحابة لكافة الأجهزة بنجاح!");
  } else {
    alert("✅ تم حفظ الإعدادات محلياً (ينصح بربط السحابة لتحديث باقي الأجهزة).");
  }
}
// 4. التحقق من الدخول بعد تحديث البيانات من السحابة
async function executeLogin() {
  const hotelId = parseInt(document.getElementById('loginHotelSelect').value);
  const role = document.getElementById('loginRoleSelect').value;
  const pinInput = document.getElementById('loginPinInput').value;

  // جلب أحدث الأكواد السحابية قبل فحص كلمة المرور
  if (cloudApiUrl) {
    await fetchDataFromCloud(true);
  }

  const targetHotel = hotelsList.find(h => h.id === hotelId);
  if (role !== 'superadmin' && targetHotel && targetHotel.status === 'suspended') { 
    alert("❌ عذراً، تم إيقاف النظام مؤقتاً عن هذا الفندق من قبل الإدارة العامة."); 
    return; 
  }
  
  if (role === 'superadmin') {
    if (pinInput !== masterSuperKey) { alert("❌ رمز السوبر أدمن غير صحيح!"); return; }
    currentRole = 'superadmin'; currentUsername = currentLang === 'ar' ? 'المالك العام' : 'Super Admin'; currentHotelId = hotelId;
  } else if (role === 'manager') {
    if (pinInput !== targetHotel.managerPin) { alert("❌ رمز مدير الفندق غير صحيح!"); return; }
    currentRole = 'manager'; currentUsername = currentLang === 'ar' ? 'مدير الفندق' : 'Hotel Manager'; currentHotelId = hotelId;
  } else if (role === 'staff') {
    const staffName = document.getElementById('loginStaffSelect').value;
    const staffObj = targetHotel.staffList.find(s => s.name === staffName);
    if (!staffObj || pinInput !== staffObj.pin) { alert("❌ كلمة المرور غير صحيحة!"); return; }
    currentRole = 'staff'; currentUsername = staffName; currentHotelId = hotelId;
  } else if (role === 'hr_supervisor') {
    if (pinInput !== targetHotel.hrPin) { alert("❌ رمز مشرف الموظفين غير صحيح!"); return; }
    currentRole = 'hr_supervisor'; currentUsername = currentLang === 'ar' ? 'مشرف الموظفين' : 'HR Supervisor'; currentHotelId = hotelId;
  } else {
    if (pinInput !== targetHotel.housePin) { alert("❌ رمز مشرف النظافة غير صحيح!"); return; }
    currentRole = 'housekeeper'; currentUsername = currentLang === 'ar' ? 'مشرف النظافة' : 'Housekeeper'; currentHotelId = housekeeper;
  }
  
  document.getElementById('loginOverlay').style.display = 'none';
  pinsAreRevealed = false;
  updateHeaderInfo();
  applyPermissions();
  if (currentRole === 'superadmin') {
    switchTab('superAdminView', null);
    renderSuperAdminControlPanel();
  } else {
    switchMainFeature('rooms', document.querySelector('.quick-access-chip'));
    selectedFloor = 1; render();
  }
}
// الخطوة 5: تهيئة المزامنة التلقائية والعمل في الخلفية
function initCloudSyncSystem() {
  // 1. سحب البيانات فور فتح التطبيق
  fetchCloudDataOnStart();

  // 2. إيقاف أي مؤقت قديم لمنع التكرار
  if (window.cloudSyncInterval) clearInterval(window.cloudSyncInterval);

  // 3. ضبط التحديث الدوري كل 30 ثانية (يمكنك تغيير 30000 إلى 60000 ليكون كل دقيقة)
  window.cloudSyncInterval = setInterval(() => {
    syncDataWithCloudNow();
  }, 30000);
}

// تشغيل النظام تلقائياً عند تحميل الصفحة
if (document.readyState === 'complete' || document.readyState === 'interactive') {
  initCloudSyncSystem();
} else {
  document.addEventListener('DOMContentLoaded', initCloudSyncSystem);
}
